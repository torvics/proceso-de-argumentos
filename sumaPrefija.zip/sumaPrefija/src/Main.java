import javax.swing.*;
import java.util.HashSet;

public class Main {
    public static void main(String[] args) {

        if (args[0] == null){
            System.out.println("ingrese números como argumento paro");
        }


        //EJERCICIO 1

        int x[] = new int[args.length];
        int suma = 0;
        for (int i = 0; i < args.length; i++) {

            x[i] = Integer.parseInt(args[i]);
            suma += x[i];
            System.out.println(x[i] + ": " + suma);

            }

            System.out.println();


            /*
              //casi te la avientas papirriquitiqui
            suma = Integer.parseInt(args[i] + args[i+1]);
            x[i] = suma;
            System.out.println(x[i]);

            System.out.println(args[i]);
             */


            /*
        for (int i = 0; i < args.length; i++) {
            System.out.println(i);

       }
        /*
        for (int i = 0; i < args.length; i++) {
            int ea = Integer.parseInt(args[i]);
            System.out.println(ea);
        }
         */

        /*
        for (int i = 1; i < args.length; i++) {
            int sumando = 0;
            Integer.parseInt(args[i])
        }

         */

        //EJERCICIO 1

        int y = Integer.parseInt(args[0]);
        HashSet<Integer> numbers = new HashSet<>();

        for (int i = 1; i < args.length; i++) {
            int num = Integer.parseInt(args[i]);
            int complement = y - num;

            if (numbers.contains(complement)) {
                System.out.println("Sí está la suma");
                return;
            }

            numbers.add(num);
        }
        System.out.println("El numero no tiene su suma ahí");


        /*
        int sum = 0;
        for (int i = 0; i < args.length; i++) {

            sum = Integer.parseInt(args[i]+args[i+1]);
            if (Integer.parseInt(args[0]) == sum){
                System.out.println("eaa");
            }else{
                System.out.println("noo");
            }
 */

        } //end main
    }
